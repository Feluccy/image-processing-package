# package_name

Description. 
The package package_name is used to:Processamento (Processing): - Match de histograma - Similaridade de estruturas - Redimensionamento de imagens Utilidades (Utils): - Leitura de imagem - Salvar imagem - Apresentar(plot) imagem - Apresentar(plot) histogramas - Apresentar(plot) resultados

Instalação
	- 
	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
  pip install image-processing-package 

```

## Usage

```python
'''python from image_processing.processing import combination combination.find_difference(image1,image2) '''
```

## Author
Fernanda Lucio

## License
[MIT](https://choosealicense.com/licenses/mit/)